/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @syahrul's author
 */
import java.io.*; 
public class baper { 
public static void main(String args[]) throws Exception{ 
InputStreamReader r=new InputStreamReader(System.in); 
BufferedReader br=new BufferedReader(r); 
System.out.println("Masukkan Nama Anda"); 
String name=br.readLine(); 
System.out.println("Selamat Datang, "+name); 
} 
}

