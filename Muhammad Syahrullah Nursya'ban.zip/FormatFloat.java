/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Toshiba
 */
class FormatFloat{
public static void main(String args[])
{
float a = 3.14f;
System.out.printf("Tampilkan a = %f", a);
}
}